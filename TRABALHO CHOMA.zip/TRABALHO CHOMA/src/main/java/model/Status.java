package model;

public enum Status {
    A_FAZER,
    EM_PROGRESSO,
    CONCLUIDO
}
